import io
import re
import logging
import pdfminer.layout
import pdfminer.high_level
from unidecode import unidecode


def process_pdf_to_txt(input_file):

    try:
        with io.BytesIO(input_file.read()) as file:
            extracted_text = ''
            no_of_pages = len(list(pdfminer.high_level.extract_pages(file))) - 1
            for page_number, page in enumerate(pdfminer.high_level.extract_pages(file)):
                for element in page:
                    if isinstance(element, pdfminer.layout.LTTextBoxHorizontal):
                        extracted_text += element.get_text()
                if page_number != no_of_pages:
                    extracted_text += '\n\nNEW PAGE\n\n'

        # ascii_converted_text = unidecode(extracted_text)

        case_fold_text = extracted_text.casefold()

        # --------------- modifies here
        ascii_converted_text_2 = case_fold_text.replace("new page", "NEW PAGE")

        # -------> normalize operations
        list_data = ascii_converted_text_2.split('\n')

        modified_data = []

        # # Define a list of punctuation marks where you want to remove spaces before
        # punctuation_to_include = ['.', ',', '?', '!', ';']

        for line in list_data:

            # line = line.replace('.', '')  # Remove dots (.)
            line = re.sub(r'^\s+', '', line)  # Remove leading whitespaces
            line = re.sub(r'\s+', ' ', line)  # Replace multiple spaces with a single space
            line = re.sub(r'"\s*(.*?)\s*"', lambda x: f'"{x.group(1)}"', line)  # Remove spaces inside double quotes
            line = re.sub(r'\s*-\s*', '-', line)  # Remove spaces around hyphens
            # line = re.sub(r'\s+\'s', '\'s', line)  # Remove space before 's
            line = re.sub(r'\s*[/\\]\s*', r'/', line)  # Remove spaces before and after / or \
            line = re.sub(r'\s*([\(\)\[\]])\s*', r'\1', line)  # Remove spaces before and after (, ), [, and ]
            line = re.sub(r'"', '', line)   # remove " symbol

            # # Remove spaces before specific punctuation marks
            # for punctuation in punctuation_to_include:
            #     line = re.sub(r'\s+' + re.escape(punctuation), punctuation, line)

            modified_data.append(line)

        nlp_data = '\n'.join(modified_data)

        def remove_long_dots(text):
            return re.sub(r"\.{2,}", "...", text)

        result = remove_long_dots(nlp_data)

        return result

    except Exception as err:
        logging.error(f"Error occurred in pdf_to_txt converter module: {str(err)}")
