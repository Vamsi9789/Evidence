"""Loader that loads data from JSON."""

import logging
from langchain.docstore.document import Document

def process_json_list(data):
    try:
        docs = []
        for indexes in data:
            page_content = indexes['page_content']
            metadata = indexes['metadata']
            document_source = metadata['source']
            page_no = metadata['page']

            metadata = dict(source=document_source, page=page_no)
            docs.append(Document(page_content=page_content, metadata=metadata))
        return docs
    except Exception as err:
        logging.error(f"Error occurred in json_list_obj_generator module: {str(err)}")

