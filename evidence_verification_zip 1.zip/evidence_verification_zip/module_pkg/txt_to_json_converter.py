
def process_txt_to_json(text_data, source_file_path):
    """This function converts text files to JSON files and saves them in a different folder."""
    try:
        pages = text_data.split('NEW PAGE')
        output_data = []
        for count, page in enumerate(pages):
            document = {
                'page_content': page.strip(),
                'metadata': {
                    'source': source_file_path,
                    'page': count+1
                }
            }
            output_data.append(document)

        return output_data

    except Exception as err:
        print(f"Error during txt_to_json_converter module: {str(err)}")
