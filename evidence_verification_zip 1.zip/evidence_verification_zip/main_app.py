
import os
import logging
import pandas as pd
import streamlit as st
from langchain_core.prompts import PromptTemplate
from langchain.chains.retrieval_qa.base import RetrievalQA
from langchain_openai import AzureChatOpenAI, AzureOpenAI
from langchain_openai import AzureOpenAIEmbeddings
from langchain_community.vectorstores import AzureSearch
from process_file_to_acs import process_blob
import query_templates as qt
import iterate_process_llm as ipl
import display_analysis_report as report
import list_azure_blobs as lzb
import time


logging.basicConfig(level=logging.INFO, format='%(levelname)s:%(message)s')

# Set page title and favicon
st.set_page_config(
    page_title="Evidence POC",
    page_icon="∞",
    layout="wide",
    initial_sidebar_state="expanded",
)
# Hide Streamlit hamburger and footer 'made with streamlit'
st.markdown("""
            <style>
            #MainMenu {visibility: hidden;}
            footer {visibility: hidden;}
            </style>
            """, unsafe_allow_html=True)

# set the overall progress bar to --> green
st.markdown(
    """
    <style>
        .stProgress > div > div > div > div {
            background-color: green;
        }
    </style>""",
    unsafe_allow_html=True,
)


os.environ["OPENAI_API_TYPE"] = "azure"
os.environ["OPENAI_API_VERSION"] = os.getenv("OPENAI_API_VERSION")
os.environ["AZURE_OPENAI_ENDPOINT"] = os.getenv("AZURE_OPENAI_ENDPOINT")
os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY")

# -----------------> MODEL CONFIGURATION
CHAT_MODEL_NAME: str = "gpt-35-turbo"
EMBEDDING_MODEL_NAME: str = "text-embedding-ada-002"

# -----------------> AZURE COGNITIVE SEARCH CONFIGURATION
VECTOR_STORE_ADDRESS: str = os.getenv("VECTOR_STORE_ADDRESS")
AZURE_COGNITIVE_SEARCH_API_KEY: str = os.getenv("AZURE_COGNITIVE_SEARCH_API_KEY")
INDEX_NAME = "policies-index"

llm = AzureChatOpenAI(deployment_name=CHAT_MODEL_NAME, temperature=0.0)
embeddings = AzureOpenAIEmbeddings(deployment=EMBEDDING_MODEL_NAME)
vector_store: AzureSearch = AzureSearch(
    azure_search_endpoint=VECTOR_STORE_ADDRESS,
    azure_search_key=AZURE_COGNITIVE_SEARCH_API_KEY,
    index_name=INDEX_NAME,
    embedding_function=embeddings.embed_query)

POLICY_CHAIN_PROMPT = PromptTemplate.from_template(qt.policy_extract_template)

qa_chain = RetrievalQA.from_chain_type(
    llm,
    retriever=vector_store.as_retriever(search_kwargs={"k": 5}),
    chain_type="stuff",
    return_source_documents=True,
    chain_type_kwargs={"prompt": POLICY_CHAIN_PROMPT},
)

# File path evidence file
password_policy_evidence_csv_file = "resources/Sample Questions Password Policy 1.csv"

st.title("Evidence Analysis POC - ")
file_upload_tab, report_data_tab = st.tabs(["Upload Files", "Analyze Data"])

with file_upload_tab:

    col1, col3, col2 = st.columns([1, 0.2, 1])

    with col1:
        uploaded_file = st.file_uploader("Choose a file")

        if uploaded_file is not None:

            # Make a copy of the uploaded file
            copied_file_path = f"{uploaded_file.name}"
            with open(copied_file_path, "wb") as f:
                f.write(uploaded_file.getbuffer())

            # Process to Azure Cognitive Search
            process_blob(st, uploaded_file)

            # Upload copy of the file to Azure Storage
            from blob_storage_upload import upload_to_azure_storage
            upload_to_azure_storage(st, copied_file_path)

    with col2:

        # Show list of blobs in Container
        lzb.list_blobs(st)


with report_data_tab:

    # col1, col2, col3, col4 = st.columns([1, 1, 1, 1])
    # with col1:
    #     # select company
    #     companies = ['Persistent_Systems', 'Sub_Company1', 'Sub_Company2']
    #     choose_company = st.selectbox("select company", options=companies, index=0)

    # with col2:
    #     # select policy
    #     policies = ['password_policy', 'policy_2nd', 'policy_3rd']
    #     choose_policy = st.selectbox("select policy", options=policies, index=0)

    if st.button("Run Analysis"):
        # if choose_company == "Persistent_Systems":

        if True:
            df = pd.read_csv(password_policy_evidence_csv_file, encoding='utf-8')

            queries_list = []
            percentage_followed_list = []
            evaluation_results_list = []

            evidence_llm_output_json_list = []
            source_doc_page_no_list = []

            # Progress bar setup
            my_bar = st.progress(0, text="Operation in progress. Please wait.")
            total_steps = len(df.index)
            current_step = 0

            for index, row in df.iterrows():
                query = row[0]
                evidence = row[1]

            # for single iteration
            # query = df['Question'][0]
            # evidence = df['Instructions'][0]

                llm_response = qa_chain({"query": query})
                logging.info(f"llm_answer1: {llm_response}")

                current_step += 1
                my_bar.progress(current_step / total_steps, text="Policy Fetched. Analyzing...")

                # get final json formatted answer from llm
                evidence_llm_output_json, source_doc_page_no = ipl.process_llm_response(st, llm, query, llm_response,
                                                                                        evidence, logging
                                                                                        )
                logging.info(f"llm_answer2: {evidence_llm_output_json}")

                queries_list.append(evidence_llm_output_json["query"])
                percentage_followed_list.append(evidence_llm_output_json["percentage_followed"])
                evaluation_results_list.append(evidence_llm_output_json["reason"])

                evidence_llm_output_json_list.append(evidence_llm_output_json)
                source_doc_page_no_list.append(source_doc_page_no)

            # Create a DataFrame
            df = pd.DataFrame(list(zip(queries_list, evaluation_results_list, percentage_followed_list)),
                              columns=['Query', 'Evaluation', 'Percentage Followed'])

            # st.title(f"{choose_company} Policy Analysis")

            def colorize(val):
                val = int(val.replace('%', ''))
                color = 'black'
                if val < 30:
                    color = 'red'
                elif val < 80:
                    color = 'yellow'
                else:
                    color = 'green'
                return f'color: {color}'

            # Display the table using Streamlit
            st.subheader("Overview Summary")
            # Apply color function to 'Percentage' column
            styled_df = df.style.applymap(colorize, subset=['Percentage Followed'])

            # # Show the table in dataframe format -- synchronised way
            # st.write(styled_df)

            # Show in tabular format --- all texts visible
            st.markdown(styled_df.hide(axis="index").to_html(), unsafe_allow_html=True)
            # st.table(df)

            # for i, j in zip(evidence_llm_output_json_list, source_doc_page_no_list):
            #
            #     # show analysis report
            #     report.show_analysis_report(st, i, j, choose_company)

            # Progress completion
            my_bar.progress(100, text="Hang on a bit!")
            time.sleep(1)
            my_bar.empty()

        else:
            pass

