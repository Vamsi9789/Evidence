import json
from langchain.chains import LLMChain
from langchain_core.prompts import PromptTemplate
import query_templates as qt


def process_llm_response(st, llm, query, llm_response, evidence, logging):
    policy_extraction_result_json_str = llm_response['result']

    # basic str --> json checks
    d_1 = policy_extraction_result_json_str.replace('\\n', '')
    d_2 = d_1.replace('\n', '')
    d_3 = d_2.replace('\\', '')

    policy_extraction_result_json = json.loads(d_3)

    if policy_extraction_result_json["are_relevant_policies_present"].casefold() == "yes":
        policy_from_llm = policy_extraction_result_json["policy_details"]

        evidence_template = PromptTemplate(
            input_variables=["query", "policy", "evidence"],
            template=qt.verify_evidence_template
        )

        llm_chat_evidence = LLMChain(llm=llm, prompt=evidence_template)
        evidence_llm_output_json_str = llm_chat_evidence.run(query=query, policy=policy_from_llm, evidence=evidence)

        # parse_llm_str1 = evidence_llm_output_json_str.split("{")[1].split("}")[0]
        # parse_llm_str2 = json.loads("{" + parse_llm_str1 + "}", strict=False)

        logging.info(f"llm_2: {evidence_llm_output_json_str}")
        # basic str --> json checks
        d_9 = evidence_llm_output_json_str.replace('\\n', '')
        d_8 = d_9.replace('\n', '')
        d_7 = d_8.replace('\\', '')

        evidence_llm_output_json = json.loads(d_7)

    # st.write(policy_extraction_result_json["are_relevant_policies_present"])
    #
    # st.write('\n\nSources:')
    # for source in llm_response["source_documents"]:
    #     st.write(source.metadata['source'], source.metadata['page'])

        return evidence_llm_output_json, llm_response["source_documents"]
