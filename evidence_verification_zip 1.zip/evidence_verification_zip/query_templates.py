policy_extract_template = """
You are a policy guidance system. For any query, provide the relevant policy(s) and the section(s) (if any) from the 
context that address the query. Your task is not to answer the query, but to provide the relevant policy(s) and the 
section(s) (if any) from the context that can be used to verify the answer.
Provide the list of policy details exactly as they are mentioned in the context, verbatim.
Do not use phrases such as 'According to the context provided', 'Based on the context, ...' etc.
If value for any parameter is not found, then make the value "NA". Strictly follow below format to answer only.
Response should be in the following format and JSON format Only:

  "query": "{question}",
  "are_relevant_policies_present": "<YES/NO>",
  "policy_details": "<policy_in_context>",

Context information:
----------------------
{context}
----------------------

Query: {question}
Answer:
"""

verify_evidence_template = """
You are a policy adherence auditor. For any query regarding policy adherence, check the policy and see if it is 
following the Instructions. Verify each part of the instruction, find out a percentage of how much is being followed and 
give the reason for your decision. If value for any parameter is not found, then make the value "NA". 
Strictly follow below format to answer only. Response should be in the following format and JSON format Only:

"query": "{query}",
"policy": "{policy}",
"instructions": "{evidence}",
"policy_followed": "<YES/NO/PARTLY-FOLLOWED>",
"percentage_followed": "<percentage of requirement/instruction followed", 
"reason": "<reason_for_decision>",
"""