
import os
import logging
from langchain_openai import AzureOpenAIEmbeddings
from langchain_community.vectorstores import AzureSearch
from langchain.text_splitter import RecursiveCharacterTextSplitter
from module_pkg import (
        pdf_to_text_converter as pdf_to_txt,
        txt_to_json_converter as txt_to_json,
        json_list_obj_generator as gen_json_list,
)


try:
    # ----------------> VECTOR STORE CONFIGURATION

    os.environ["OPENAI_API_TYPE"] = "azure"
    os.environ["AZURE_OPENAI_API_VERSION"] = "2023-09-15-preview"
    os.environ["AZURE_OPENAI_ENDPOINT"] = "https://genai-coe-msft-evidence.openai.azure.com/"
    os.environ["OPENAI_API_KEY"] = "350d349b9ef6428c8f8f561ce76567ec"

    # -----------------> MODEL CONFIGURATION
    EMBEDDING_MODEL_NAME: str = "text-embedding-ada-002"
    AZURE_OPENAI_API_VERSION = "2023-09-15-preview"
    AZURE_OPENAI_ENDPOINT = "https://genai-coe-msft-evidence.openai.azure.com/"
    OPENAI_API_KEY = "350d349b9ef6428c8f8f561ce76567ec"

    # -----------------> AZURE COGNITIVE SEARCH CONFIGURATION
    VECTOR_STORE_ADDRESS: str = "https://genaicoemsftevidencesearch.search.windows.net"
    AZURE_COGNITIVE_SEARCH_API_KEY: str = "Q8upTdo1cCvf4SsAKMRyZ4N57Qlh9cFMcTXk6li8p2AzSeDxTy44"

    embeddings: AzureOpenAIEmbeddings = AzureOpenAIEmbeddings(
                                            azure_deployment=EMBEDDING_MODEL_NAME,
                                            openai_api_version=AZURE_OPENAI_API_VERSION,
                                            azure_endpoint=AZURE_OPENAI_ENDPOINT,
                                            api_key=OPENAI_API_KEY,
                                       )

    # # Initiate Splitter client
    recursive_text_splitter = RecursiveCharacterTextSplitter(chunk_size=2000, chunk_overlap=10)
    # token_text_splitter = TokenTextSplitter(chunk_size=1000, chunk_overlap=10)

except Exception as err:
    logging.error(f"Error in function initialization: {str(err)}")


def insert_index_to_azcs(st, file_name, index_data):
    try:
        only_file_name = file_name.split("/")[-1].lower()
        index_name = f"policies-index"

        azcs_vector_store: AzureSearch = AzureSearch(
            azure_search_endpoint=VECTOR_STORE_ADDRESS,
            azure_search_key=AZURE_COGNITIVE_SEARCH_API_KEY,
            index_name=index_name,
            embedding_function=embeddings.embed_query,
        )

        # Split data into tokens
        chunk_data = recursive_text_splitter.split_documents(index_data)

        keys = []
        for i in range(len(chunk_data)):
            keys.append(only_file_name + f"-{i}")  # ex:- file.pdf-0, file.pdf-1 ....

        # add the document to azure search
        azcs_vector_store.add_documents(documents=chunk_data, keys=keys)

    except Exception as err:
        logging.error(f"Error in sub-function (insert_index_to_azcs): {str(err)}")


def process_blob(st, blob):

    try:
        file_name = blob.name   # ex : docs-hr/file.pdf
        extension = file_name.rsplit(".", 1)[1]
        blob_url = f"policies/{file_name}"

        if extension != "pdf":
            logging.info(f"""File format is not supported. required 'pdf', got :'{extension}'""")
            pass
        else:
            extracted_txt_lower = pdf_to_txt.process_pdf_to_txt(blob)

            converted_json_list = txt_to_json.process_txt_to_json(extracted_txt_lower, blob_url)
            index_data = gen_json_list.process_json_list(converted_json_list)

            # Call function to add index data
            insert_index_to_azcs(st, file_name, index_data)

    except Exception as err:
        logging.error(f"Error in sub-function (process_blob): {str(err)}")
