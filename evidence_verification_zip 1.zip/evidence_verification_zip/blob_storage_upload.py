import os
from azure.storage.blob import BlobServiceClient

# Get Azure Storage connection details
azure_storage_connection_string = os.getenv("CONNECTION_STRING_CONTAINER")
container_name = "policies"

# Create a BlobServiceClient object
blob_service_client = BlobServiceClient.from_connection_string(azure_storage_connection_string)


def upload_to_azure_storage(st, file):
    try:
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=file)
        blob_client.upload_blob(file, overwrite=True)
        st.success(f"{file} uploaded to Azure Storage!")
        file_url = blob_client.url

    except Exception as e:
        st.error(f"Error uploading file: {e}")

    # if uploaded_files is not None:
    #     if st.button("Upload to Azure Storage"):
    #         for uploaded_file in uploaded_files:
    #             upload_to_azure_storage(st, uploaded_file)
    #

    # if uploaded_file is not None:
    #     process_blob(st, uploaded_file)

