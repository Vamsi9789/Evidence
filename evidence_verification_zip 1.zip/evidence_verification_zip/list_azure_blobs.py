import os
from azure.storage.blob import BlobServiceClient
from dotenv import load_dotenv
load_dotenv()


def list_blobs(st):
    # Azure Blob Storage settings
    connection_string = os.getenv("CONNECTION_STRING_CONTAINER")
    container_name = "policies"

    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    container_client = blob_service_client.get_container_client(container_name)
    blob_list = container_client.list_blobs()

    st.markdown(f"Files available in container '{container_name}':")
    for i, blob in enumerate(blob_list):
        st.write(i+1, blob.name)

