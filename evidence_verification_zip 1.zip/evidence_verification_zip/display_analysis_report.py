import re
import webbrowser
from datetime import datetime, timedelta
from azure.storage.blob import generate_blob_sas, BlobSasPermissions


def colored_progress_bar(st, progress):
    """Displays a progress bar with color based on percentage."""
    if progress < 30:
        color = 'red'
    elif progress < 80:
        color = 'yellow'
    else:
        color = 'green'

    st.markdown(f"""<style>
        .stProgress > div > div > div > div {{
        background-color: {color};
        }}
    </style>""", unsafe_allow_html=True)

    progress_bar = st.progress(progress)
    return progress_bar


def generate_blob_sas_url(blob_name_with_container, sas_expiry_minutes=10):
    account_name = "genaicoemsftstorage"
    account_key = "uOWoimiaso+GvScSMUkF1iFrpIluC5KcITCR5Al+DOvU8iIPiwyGseTpXQ3wGdBmYhaa8mjXfk5j+AStmkctBQ=="
    container_name = "policies"
    blob_name = blob_name_with_container.split('/')[-1]
    blob_sas_token = generate_blob_sas(
        account_name=account_name,
        container_name=container_name,
        blob_name=blob_name,
        account_key=account_key,
        permission=BlobSasPermissions(read=True),  # Adjust permissions as needed
        expiry=datetime.utcnow() + timedelta(minutes=sas_expiry_minutes),
    )

    blob_url_with_sas = f"https://{account_name}.blob.core.windows.net/{container_name}" \
                        f"/{blob_name}?{blob_sas_token}"

    return blob_url_with_sas


def show_analysis_report(st, data, source_metadata, company_name):

    percentage_followed = data["percentage_followed"]
    int_percentage_followed = re.search(r'\d+', percentage_followed).group()

    # st.title(f"{company_name} Policy Analysis")
    col1, col2 = st.columns([1.5, 0.3])
    with col1:
        st.subheader("Query")
        st.write(data["query"])
    with col2:
        # progress bar
        progress_value = int(int_percentage_followed)  # Assuming this is an integer
        colored_progress_bar(st, progress_value)
        # st.progress(progress_value)
        # Display percentage as text
        st.metric("Percentage Followed", data["percentage_followed"], delta=None)

    col3, col8, col4 = st.columns([1.5, 0.1, 0.4])
    with col3:
        st.subheader("Policy")
        expander = st.expander(data["policy"])
        expander.write("")

    with col4:
        # for source in source_metadata:
        #     st.write(f"{source.metadata['source']}, {source.metadata['page']}[@](%s)"
        #              % generate_blob_sas_url(source.metadata['source']))

        if data["policy_followed"].casefold() != "no":
            st.subheader('\n\nSources:')
            for source in source_metadata[0:3]:
                sas_url = generate_blob_sas_url(source.metadata['source'])
                st.write(f"[{source.metadata['source']}, {source.metadata['page']}]({sas_url})")

    # Columns for horizontal layout
    col5, col6, col7 = st.columns([0.8, 1.3, 0.9])

    with col5:
        st.subheader("Instructions")
        st.write(data["instructions"])

    with col6:
        st.subheader("Reason")
        st.write(data["reason"])

    with col7:
        st.metric("Policy Adherence", data["policy_followed"])
